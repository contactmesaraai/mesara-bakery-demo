import React, { useState } from 'react';
import { CartItem } from '../types';
import { STORE_INFO } from '../data/products';
import { MessageCircle, Copy, Check, X, Send, Smartphone, ArrowRight } from 'lucide-react';

interface WhatsAppOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  cartTotal: number;
}

export const WhatsAppOrderModal: React.FC<WhatsAppOrderModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  cartTotal,
}) => {
  if (!isOpen) return null;

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('Gandhi Bazaar, Bengaluru - 560004');
  const [customListText, setCustomListText] = useState('');
  const [copied, setCopied] = useState(false);
  const [simulatedReceived, setSimulatedReceived] = useState(false);

  // Generate message preview
  const generateMessage = () => {
    let msg = `*Namaskara Sri Lakshmi Stores!* 🙏\nI would like to order fresh provisions from your website:\n\n`;

    if (cartItems.length > 0) {
      cartItems.forEach((item, index) => {
        msg += `${index + 1}. *${item.product.name}* (${item.selectedSize}) x ${item.quantity} = ₹${item.price * item.quantity}\n`;
      });
      msg += `\n*Total Order Amount:* ₹${cartTotal}`;
      if (cartTotal < STORE_INFO.freeDeliveryThreshold) {
        msg += ` (+₹${STORE_INFO.deliveryFee} delivery)`;
      } else {
        msg += ` (FREE Doorstep Delivery)`;
      }
    } else if (customListText.trim()) {
      msg += `*My Grocery List:*\n${customListText.trim()}\n`;
    } else {
      msg += `1. Sona Masoori Raw Rice (5 kg bag) x 1 = ₹360\n2. Desi A2 Cow Ghee (500 ml) x 1 = ₹649\n3. Kumbakonam Filter Coffee (500 g) x 1 = ₹240\n\n*Estimated Total:* ~₹1,249 (Free Delivery)`;
    }

    msg += `\n\n*Customer Details:*`;
    msg += `\nName: ${customerName || 'Neighborhood Customer'}`;
    msg += `\nPhone: ${customerPhone || '+91 98450 XXXXX'}`;
    msg += `\nDelivery Address: ${customerAddress}`;
    msg += `\nPayment Mode: Cash / UPI on Delivery`;

    return msg;
  };

  const currentMessage = generateMessage();

  const handleCopy = () => {
    navigator.clipboard.writeText(currentMessage);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendWhatsApp = () => {
    const encoded = encodeURIComponent(currentMessage);
    const whatsappUrl = `https://wa.me/${STORE_INFO.whatsappNumber}?text=${encoded}`;
    // Open in new tab or trigger simulation
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    setSimulatedReceived(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full border border-stone-200 shadow-2xl overflow-hidden relative my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 to-emerald-950 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-heading font-bold text-lg text-white">Direct WhatsApp Order</h3>
              <p className="text-xs text-emerald-200">Sri Lakshmi Stores (+91 98450 12345)</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Shop Owner Note */}
          <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-200 text-xs text-indigo-950 flex items-start gap-2.5">
            <Smartphone className="w-4 h-4 text-indigo-700 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold text-indigo-900">Why Shopkeepers Love This Feature:</strong>
              <p className="text-indigo-800 text-[11px] mt-0.5">
                Customers don’t need to download any app! Orders arrive formatted directly onto your shop’s WhatsApp number with exact item weights, prices, customer name, and address.
              </p>
            </div>
          </div>

          {/* Customer inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="font-semibold text-stone-700 block mb-1">Your Name</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="e.g. Anand Sharma"
                className="w-full px-3 py-2 rounded-lg border border-stone-200 bg-stone-50 focus:bg-white focus:outline-none focus:border-emerald-600 text-stone-900 text-xs"
              />
            </div>
            <div>
              <label className="font-semibold text-stone-700 block mb-1">Mobile Number</label>
              <input
                type="tel"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="+91 98450 12345"
                className="w-full px-3 py-2 rounded-lg border border-stone-200 bg-stone-50 focus:bg-white focus:outline-none focus:border-emerald-600 text-stone-900 text-xs"
              />
            </div>
          </div>

          <div>
            <label className="font-semibold text-stone-700 block mb-1 text-xs">Delivery Address</label>
            <input
              type="text"
              value={customerAddress}
              onChange={(e) => setCustomerAddress(e.target.value)}
              placeholder="House/Flat No., Street, Pincode"
              className="w-full px-3 py-2 rounded-lg border border-stone-200 bg-stone-50 focus:bg-white focus:outline-none focus:border-emerald-600 text-stone-900 text-xs"
            />
          </div>

          {cartItems.length === 0 && (
            <div>
              <label className="font-semibold text-stone-700 block mb-1 text-xs">
                Or Type / Paste Custom Provisions List:
              </label>
              <textarea
                rows={3}
                value={customListText}
                onChange={(e) => setCustomListText(e.target.value)}
                placeholder="e.g. 5kg Sona Masoori Rice, 1kg Toor Dal, 500g Filter Coffee..."
                className="w-full px-3 py-2 rounded-lg border border-stone-200 bg-stone-50 focus:bg-white focus:outline-none focus:border-emerald-600 text-stone-900 text-xs font-mono"
              />
            </div>
          )}

          {/* Formatted Message Preview */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                WhatsApp Message Preview
              </span>
              <button
                onClick={handleCopy}
                className="inline-flex items-center gap-1 text-[11px] font-semibold text-stone-600 hover:text-stone-900 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied to Clipboard' : 'Copy Text'}</span>
              </button>
            </div>

            <div className="bg-[#EFEAE2] p-4 rounded-2xl border border-stone-300 font-sans text-xs text-stone-800 whitespace-pre-line shadow-inner max-h-48 overflow-y-auto">
              <div className="bg-white p-3 rounded-lg shadow-2xs border border-stone-200 max-w-sm ml-auto">
                {currentMessage}
              </div>
            </div>
          </div>

          {/* Simulation Feedback Alert */}
          {simulatedReceived && (
            <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-950 text-xs space-y-1">
              <p className="font-bold flex items-center gap-1.5 text-emerald-800">
                <Check className="w-4 h-4 text-emerald-600" />
                WhatsApp Message Sent to Shopkeeper!
              </p>
              <p className="text-[11px] text-stone-600">
                Sri Lakshmi Stores receives this formatted order on +91 98450 12345, packs the order, and dispatches via their delivery boy within 60-90 minutes.
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3">
          <button
            onClick={() => setSimulatedReceived(true)}
            className="text-xs font-semibold text-stone-700 hover:text-stone-900 underline underline-offset-4 cursor-pointer"
          >
            Simulate Shopkeeper Reception
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-700 hover:bg-stone-200 transition-colors cursor-pointer"
            >
              Close
            </button>
            <button
              onClick={handleSendWhatsApp}
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Launch WhatsApp Chat</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
