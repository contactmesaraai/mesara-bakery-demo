import React, { useState } from 'react';
import { Product } from '../types';
import { ShoppingBag, MessageCircle, Star, Eye, Plus, Minus, Check } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, size: string, price: number, quantity: number) => void;
  onQuickView: (product: Product) => void;
  onDirectWhatsApp: (product: Product, size: string, price: number) => void;
  currentCartQty?: number;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onAddToCart,
  onQuickView,
  onDirectWhatsApp,
  currentCartQty = 0,
}) => {
  const [selectedSizeIndex, setSelectedSizeIndex] = useState(0);
  const [itemQty, setItemQty] = useState(1);
  const [justAdded, setJustAdded] = useState(false);

  const currentVariant = product.availableSizes[selectedSizeIndex] || {
    size: product.unit,
    price: product.price,
    originalPrice: product.originalPrice,
  };

  const discountPercent = Math.round(
    ((currentVariant.originalPrice - currentVariant.price) / currentVariant.originalPrice) * 100
  );

  const handleAdd = () => {
    onAddToCart(product, currentVariant.size, currentVariant.price, itemQty);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1200);
  };

  return (
    <article className="bg-white rounded-2xl border border-stone-200/90 overflow-hidden flex flex-col justify-between group hover:border-amber-400/80 hover:shadow-md transition-all duration-200">
      <div>
        {/* Visual Frame */}
        <div className="relative bg-gradient-to-br from-stone-50 via-amber-50/20 to-stone-100/70 p-6 flex flex-col items-center justify-center min-h-[170px] border-b border-stone-100">
          {/* Subtle Origin Kicker */}
          <div className="absolute top-3 left-3 text-[11px] font-medium text-stone-500 flex items-center gap-1">
            <span>{product.origin}</span>
          </div>

          {/* Quick View Button on top-right */}
          <button
            onClick={() => onQuickView(product)}
            className="absolute top-3 right-3 p-1.5 rounded-lg bg-white/80 hover:bg-white text-stone-600 hover:text-stone-900 shadow-2xs border border-stone-200/80 transition-colors cursor-pointer"
            title="Quick Preview Details"
            aria-label={`Quick view ${product.name}`}
          >
            <Eye className="w-3.5 h-3.5" />
          </button>

          {/* Large Centered Visual Symbol / Product Emblem */}
          <div className="w-20 h-20 rounded-2xl bg-white shadow-2xs border border-stone-200/70 flex items-center justify-center text-4xl group-hover:scale-105 transition-transform duration-200">
            {product.emoji}
          </div>

          {/* Quiet Status / Best Seller Text */}
          {product.isBestSeller && (
            <div className="absolute bottom-2 left-3 text-[10px] font-semibold text-amber-800">
              ★ Neighborhood Bestseller
            </div>
          )}

          {discountPercent > 0 && (
            <div className="absolute bottom-2 right-3 text-[10px] font-bold text-emerald-700 tabular-nums">
              Save {discountPercent}%
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-3">
          {/* Category & Kannada Name as unboxed metadata */}
          <div className="flex items-center justify-between text-xs text-stone-500">
            <span>{product.categoryLabel}</span>
            {product.kannadaName && (
              <span className="text-amber-800/80 font-medium text-[11px]">{product.kannadaName}</span>
            )}
          </div>

          {/* Product Title */}
          <h3
            onClick={() => onQuickView(product)}
            className="font-heading font-bold text-base text-stone-900 group-hover:text-amber-800 transition-colors cursor-pointer line-clamp-2 leading-snug"
          >
            {product.name}
          </h3>

          <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
            {product.description}
          </p>

          {/* Clean Unboxed Rating */}
          <div className="flex items-center gap-2 text-xs text-stone-500">
            <span className="flex items-center gap-1 font-semibold text-stone-800">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
              {product.rating.toFixed(1)}
            </span>
            <span aria-hidden="true">·</span>
            <span>{product.reviewCount} verified reviews</span>
          </div>

          {/* Pack Size Selector */}
          {product.availableSizes.length > 1 && (
            <div className="pt-1">
              <label className="text-[11px] font-medium text-stone-500 block mb-1.5">Select Pack Size:</label>
              <div className="flex flex-wrap gap-1.5">
                {product.availableSizes.map((variant, idx) => (
                  <button
                    key={variant.size}
                    onClick={() => setSelectedSizeIndex(idx)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                      selectedSizeIndex === idx
                        ? 'bg-amber-100 text-amber-900 border border-amber-300 font-semibold shadow-2xs'
                        : 'bg-stone-50 text-stone-700 hover:bg-stone-100 border border-stone-200'
                    }`}
                  >
                    {variant.size}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Pricing & Action Section */}
      <div className="p-4 pt-2 border-t border-stone-100 space-y-3 bg-stone-50/40">
        {/* Price Row */}
        <div className="flex items-baseline justify-between">
          <div>
            <span className="text-xs text-stone-500 mr-1">Price:</span>
            <span className="text-lg font-extrabold text-stone-900 tabular-nums">
              ₹{currentVariant.price}
            </span>
            {currentVariant.originalPrice > currentVariant.price && (
              <span className="ml-2 text-xs text-stone-400 line-through tabular-nums">
                ₹{currentVariant.originalPrice}
              </span>
            )}
          </div>
          <span className="text-[11px] text-stone-500 font-medium">
            for {currentVariant.size}
          </span>
        </div>

        {/* Quantity Stepper & Add to Cart button */}
        <div className="flex items-center gap-2">
          {/* Stepper */}
          <div className="flex items-center border border-stone-200 rounded-lg bg-white px-1 py-0.5">
            <button
              onClick={() => setItemQty(Math.max(1, itemQty - 1))}
              disabled={itemQty <= 1}
              className="p-1 text-stone-500 hover:text-stone-900 disabled:opacity-30 cursor-pointer"
              aria-label="Decrease quantity"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="w-7 text-center text-xs font-bold tabular-nums text-stone-800">
              {itemQty}
            </span>
            <button
              onClick={() => setItemQty(itemQty + 1)}
              className="p-1 text-stone-500 hover:text-stone-900 cursor-pointer"
              aria-label="Increase quantity"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Add to Bag */}
          <button
            onClick={handleAdd}
            className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              justAdded
                ? 'bg-emerald-600 text-white'
                : 'bg-stone-900 hover:bg-stone-800 text-white shadow-xs'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added to Bag</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5 text-amber-300" />
                <span>Add to Bag</span>
              </>
            )}
          </button>
        </div>

        {/* WhatsApp One-Click Order Button */}
        <button
          onClick={() => onDirectWhatsApp(product, currentVariant.size, currentVariant.price * itemQty)}
          className="w-full py-1.5 px-3 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[11px] font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
        >
          <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
          <span>Quick Order {itemQty > 1 ? `(${itemQty}x)` : ''} via WhatsApp</span>
        </button>
      </div>
    </article>
  );
};
