import React from 'react';
import { STORE_INFO } from '../data/products';
import { MapPin, Phone, Clock, ShieldCheck, Heart, Award, Navigation, MessageCircle } from 'lucide-react';

export const StoreInfoSection: React.FC = () => {
  return (
    <section id="story" className="py-14 bg-stone-100/70 border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-12">
        
        {/* Section Header */}
        <div className="max-w-3xl space-y-2">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
            Heritage & Trust
          </span>
          <h2 className="text-2xl sm:text-3xl font-heading font-extrabold text-stone-900 tracking-tight">
            Four Decades of Purity in Gandhi Bazaar
          </h2>
          <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
            Founded in 1984 on Temple Road, Sri Lakshmi Stores has supplied three generations of South Bangalore families with unadulterated staples, traditional bilona ghee, and hand-roasted spices.
          </p>
        </div>

        {/* 2-Column Grid: Store Story & Location Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Story & Philosophy */}
          <div className="lg:col-span-7 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-white border border-stone-200/80 shadow-2xs space-y-2">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-sm">
                  🌾
                </div>
                <h3 className="font-heading font-bold text-sm text-stone-900">Zero Chemical Polish</h3>
                <p className="text-xs text-stone-600 leading-normal">
                  Our toor, moong, and urad dals retain their natural bran layer, giving maximum flavor and vital nutrients.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-stone-200/80 shadow-2xs space-y-2">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-sm">
                  🍯
                </div>
                <h3 className="font-heading font-bold text-sm text-stone-900">Slow Wood-Pressing</h3>
                <p className="text-xs text-stone-600 leading-normal">
                  Groundnut and gingelly sesame oils are pressed in wooden chekku under 40°C without solvent chemical refining.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-stone-200/80 shadow-2xs space-y-2">
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-sm">
                  ☕
                </div>
                <h3 className="font-heading font-bold text-sm text-stone-900">Fresh Daily Grinding</h3>
                <p className="text-xs text-stone-600 leading-normal">
                  Filter coffee beans and turmeric roots are ground daily so customers get invigorating aroma every morning.
                </p>
              </div>
            </div>

            {/* In-House Store Guarantee */}
            <div className="p-5 rounded-2xl bg-white border border-stone-200/90 shadow-2xs space-y-3">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-700" />
                <h3 className="font-heading font-bold text-base text-stone-900">
                  Our Neighborhood Promise to You
                </h3>
              </div>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                "If you are ever dissatisfied with the flavor of our sambar powder, the aroma of our A2 ghee, or the cooking texture of our aged rice, return it to our counter for an instant 100% refund or replacement with no questions asked."
              </p>
              <div className="flex items-center justify-between pt-2 border-t border-stone-100 text-xs text-stone-500">
                <span className="font-semibold text-stone-800">— S. N. Lakshmi Narasimha & Sons</span>
                <span>Founders, Sri Lakshmi Stores</span>
              </div>
            </div>
          </div>

          {/* Location & Visiting Hours Card */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-stone-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-amber-700" />
                <h3 className="font-heading font-bold text-base text-stone-900">
                  Visit Our Physical Store
                </h3>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                Open All 7 Days
              </span>
            </div>

            {/* Address */}
            <div className="space-y-1 text-xs">
              <span className="font-bold text-stone-800 block">Store Address:</span>
              <p className="text-stone-600 leading-relaxed">
                {STORE_INFO.address}
              </p>
              <p className="text-[11px] text-amber-800 font-medium pt-1">
                Landmarks: 100 meters from Vidyarthi Bhavan, opposite Lakshmi Temple entrance.
              </p>
            </div>

            {/* Timings */}
            <div className="p-3.5 rounded-2xl bg-stone-50 border border-stone-200 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-stone-700 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-stone-500" />
                  Store Timings
                </span>
                <span className="text-[11px] font-bold text-emerald-700">Currently Open</span>
              </div>
              <div className="text-stone-600 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span>Monday - Saturday:</span>
                  <span className="font-medium text-stone-900">7:30 AM – 9:30 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday:</span>
                  <span className="font-medium text-stone-900">7:30 AM – 9:00 PM</span>
                </div>
                <div className="flex justify-between text-amber-800 font-medium pt-1 border-t border-stone-200">
                  <span>Home Delivery Hours:</span>
                  <span>8:00 AM – 8:30 PM</span>
                </div>
              </div>
            </div>

            {/* Quick Action buttons */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <a
                href={`tel:${STORE_INFO.phone}`}
                className="py-2.5 px-3 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-amber-300" />
                <span>Call Store</span>
              </a>

              <a
                href={`https://wa.me/${STORE_INFO.whatsappNumber}`}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp Store</span>
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
