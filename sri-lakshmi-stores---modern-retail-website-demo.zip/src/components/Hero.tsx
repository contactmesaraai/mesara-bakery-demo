import React, { useState } from 'react';
import { ShoppingBag, MessageCircle, MapPin, CheckCircle2, AlertCircle, Sparkles, ArrowRight, Truck, ShieldCheck, Heart } from 'lucide-react';
import { STORE_INFO } from '../data/products';

interface HeroProps {
  onExploreCatalog: () => void;
  onOpenWhatsAppModal: () => void;
  onSelectCategory: (categoryId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreCatalog,
  onOpenWhatsAppModal,
  onSelectCategory,
}) => {
  const [pincode, setPincode] = useState('560004');
  const [pincodeStatus, setPincodeStatus] = useState<{
    tested: boolean;
    available: boolean;
    message: string;
    subtext: string;
  }>({
    tested: true,
    available: true,
    message: 'Express 60-90 Mins Delivery Available!',
    subtext: 'Delivering from Gandhi Bazaar store to Basavanagudi & surrounding areas. Free delivery above ₹499.',
  });

  const handleCheckPincode = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPin = pincode.trim();
    if (cleanPin.length !== 6 || !/^\d+$/.test(cleanPin)) {
      setPincodeStatus({
        tested: true,
        available: false,
        message: 'Please enter a valid 6-digit Indian pincode.',
        subtext: 'Example: 560004, 560019, 560070',
      });
      return;
    }

    if (STORE_INFO.servicedPincodes.includes(cleanPin)) {
      setPincodeStatus({
        tested: true,
        available: true,
        message: `Express Doorstep Delivery Available in ${cleanPin}!`,
        subtext: `Orders placed now arrive within ${STORE_INFO.expressDeliveryTime}. Cash & UPI accepted on delivery.`,
      });
    } else if (cleanPin.startsWith('560')) {
      setPincodeStatus({
        tested: true,
        available: true,
        message: `Standard Same-Day Delivery to ${cleanPin}`,
        subtext: 'Delivered by 7:30 PM today via dedicated delivery personnel. Free delivery above ₹499.',
      });
    } else {
      setPincodeStatus({
        tested: true,
        available: false,
        message: `Pincode ${cleanPin} is outside our local express radius.`,
        subtext: 'We currently deliver across Bengaluru South & Central. For bulk orders outside, order via WhatsApp!',
      });
    }
  };

  return (
    <section id="hero" className="relative overflow-hidden bg-gradient-to-b from-amber-50/70 via-stone-50 to-stone-50 border-b border-stone-200/80 pt-8 pb-12 sm:pb-16">
      {/* Decorative subtle texture patterns */}
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none bg-[radial-gradient(#78350f_1px,transparent_1px)] [background-size:16px_16px]"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Store Value Proposition */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100/80 border border-amber-200/80 text-amber-900 text-xs font-semibold shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-amber-600"></span>
              <span>Gandhi Bazaar’s Trusted Grocer Since 1984</span>
              <span className="text-amber-500">·</span>
              <span className="font-normal text-amber-800">No. 42, Temple Road</span>
            </div>

            <div className="space-y-3">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-stone-900 font-heading leading-[1.15]">
                Fresh Daily Provisions & <span className="text-amber-700">Authentic Spices</span> at Your Doorstep
              </h1>
              <p className="text-base sm:text-lg text-stone-600 max-w-2xl leading-relaxed">
                Hand-picked unpolished dals, 100% Desi A2 cow ghee, stone-milled flours, and freshly ground Salem spices. Order easily online or directly over WhatsApp with prompt 90-minute neighborhood delivery.
              </p>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                onClick={onExploreCatalog}
                className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-semibold text-sm shadow-sm transition-all hover:shadow-md cursor-pointer group"
              >
                <ShoppingBag className="w-4 h-4 text-amber-200 group-hover:scale-110 transition-transform" />
                <span>Browse Provisions Catalog</span>
                <ArrowRight className="w-4 h-4 text-amber-200 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                onClick={onOpenWhatsAppModal}
                className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-sm shadow-sm transition-all cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
                <span>Quick WhatsApp Order</span>
              </button>
            </div>

            {/* Interactive Pincode Delivery Checker */}
            <div id="pincode-check" className="bg-white rounded-2xl p-4 sm:p-5 border border-stone-200 shadow-xs max-w-xl">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-stone-700 flex items-center gap-1.5">
                  <Truck className="w-4 h-4 text-amber-700" />
                  Check Doorstep Delivery To Your Area
                </span>
                <span className="text-[11px] font-medium text-emerald-700">Same-Day Active</span>
              </div>

              <form onSubmit={handleCheckPincode} className="flex gap-2">
                <div className="relative flex-1">
                  <MapPin className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
                  <input
                    type="text"
                    maxLength={6}
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value)}
                    placeholder="Enter 6-digit Pincode (e.g. 560004)"
                    className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-stone-200 bg-stone-50 text-stone-900 focus:bg-white focus:outline-none focus:border-amber-600"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold transition-colors cursor-pointer shrink-0"
                >
                  Check Status
                </button>
              </form>

              {pincodeStatus.tested && (
                <div className={`mt-3 p-3 rounded-xl text-xs flex items-start gap-2.5 ${
                  pincodeStatus.available 
                    ? 'bg-emerald-50/80 border border-emerald-200 text-emerald-900' 
                    : 'bg-amber-50 border border-amber-200 text-amber-900'
                }`}>
                  {pincodeStatus.available ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <p className="font-bold">{pincodeStatus.message}</p>
                    <p className="text-[11px] text-stone-600 mt-0.5">{pincodeStatus.subtext}</p>
                  </div>
                </div>
              )}
            </div>

          </div>

          {/* Right Column: Visual Featured Showcase Card */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-3xl p-6 border border-stone-200/90 shadow-sm relative overflow-hidden">
              {/* Top Accent Ribbon */}
              <div className="flex items-center justify-between pb-4 border-b border-stone-100">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🪔</span>
                  <div>
                    <h2 className="font-heading font-bold text-stone-900 text-base leading-tight">Sri Lakshmi Stores</h2>
                    <p className="text-[11px] text-stone-500">Gandhi Bazaar Heritage Provisions</p>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                  Daily Fresh Batch
                </span>
              </div>

              {/* 3 Featured Signature Products highlight */}
              <div className="space-y-3 py-4">
                <div
                  onClick={() => onSelectCategory('oils_ghee')}
                  className="flex items-center justify-between p-3 rounded-xl bg-amber-50/50 hover:bg-amber-100/60 border border-amber-100 transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-lg bg-amber-200/60 flex items-center justify-center text-2xl group-hover:scale-105 transition-transform">
                      🍯
                    </div>
                    <div>
                      <span className="font-bold text-sm text-stone-900 block leading-tight">
                        Desi A2 Bilona Cow Ghee
                      </span>
                      <span className="text-xs text-stone-500">Cultured Butter Churned · 500ml Glass Jar</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-amber-900 block tabular-nums">₹649</span>
                    <span className="text-[10px] text-stone-400 line-through tabular-nums">₹720</span>
                  </div>
                </div>

                <div
                  onClick={() => onSelectCategory('grains')}
                  className="flex items-center justify-between p-3 rounded-xl bg-stone-50 hover:bg-stone-100 border border-stone-100 transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-lg bg-stone-200/60 flex items-center justify-center text-2xl group-hover:scale-105 transition-transform">
                      🌾
                    </div>
                    <div>
                      <span className="font-bold text-sm text-stone-900 block leading-tight">
                        Aged Sona Masoori Rice (18M)
                      </span>
                      <span className="text-xs text-stone-500">Sweet Fragrance · 5 kg Bag</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-stone-900 block tabular-nums">₹360</span>
                    <span className="text-[10px] text-stone-400 line-through tabular-nums">₹420</span>
                  </div>
                </div>

                <div
                  onClick={() => onSelectCategory('beverages')}
                  className="flex items-center justify-between p-3 rounded-xl bg-stone-50 hover:bg-stone-100 border border-stone-100 transition-colors cursor-pointer group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-lg bg-amber-100/60 flex items-center justify-center text-2xl group-hover:scale-105 transition-transform">
                      ☕
                    </div>
                    <div>
                      <span className="font-bold text-sm text-stone-900 block leading-tight">
                        Kumbakonam Degree Filter Coffee
                      </span>
                      <span className="text-xs text-stone-500">Fresh Roasted 80:20 Blend · 500g</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-stone-900 block tabular-nums">₹240</span>
                    <span className="text-[10px] text-stone-400 line-through tabular-nums">₹275</span>
                  </div>
                </div>
              </div>

              {/* Trust Guarantee Box */}
              <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600">
                <span className="flex items-center gap-1 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  FSSAI #11221334000892
                </span>
                <span className="flex items-center gap-1 font-medium">
                  <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500/20" />
                  Loved by 2,400+ Families
                </span>
              </div>
            </div>
          </div>

        </div>

        {/* 4-Item Feature / Credibility Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12 pt-8 border-t border-stone-200/80">
          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/70 border border-stone-200/60">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0 font-bold text-xs">
              38y
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900 leading-tight">Neighborhood Trust</h4>
              <p className="text-[11px] text-stone-500 mt-0.5">Serving Basavanagudi & South Bangalore since 1984</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/70 border border-stone-200/60">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0 font-bold text-xs">
              ⚡
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900 leading-tight">Express 90-Min Delivery</h4>
              <p className="text-[11px] text-stone-500 mt-0.5">Within 5 km radius. Free above ₹499 order</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/70 border border-stone-200/60">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-800 flex items-center justify-center shrink-0 font-bold text-xs">
              🌾
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900 leading-tight">Zero Polish & Pure</h4>
              <p className="text-[11px] text-stone-500 mt-0.5">Direct farm sourced pulses, raw oils, and whole spices</p>
            </div>
          </div>

          <div className="flex items-start gap-3 p-3 rounded-xl bg-white/70 border border-stone-200/60">
            <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-800 flex items-center justify-center shrink-0 font-bold text-xs">
              ₹
            </div>
            <div>
              <h4 className="text-xs font-bold text-stone-900 leading-tight">UPI / Cash on Delivery</h4>
              <p className="text-[11px] text-stone-500 mt-0.5">Google Pay, PhonePe, or cash after inspection</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
