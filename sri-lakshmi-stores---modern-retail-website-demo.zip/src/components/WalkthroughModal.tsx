import React from 'react';
import { X, Sparkles, MessageCircle, DollarSign, Smartphone, ShieldCheck, MapPin, CheckCircle2, ArrowRight } from 'lucide-react';

interface WalkthroughModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartDemo: () => void;
}

export const WalkthroughModal: React.FC<WalkthroughModalProps> = ({
  isOpen,
  onClose,
  onStartDemo,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-stone-200 shadow-2xl overflow-hidden relative my-6">
        
        {/* Header with MESARA AI original logo */}
        <div className="bg-gradient-to-r from-stone-900 via-indigo-950 to-stone-900 text-white p-6 relative">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-10-22_at_10.37.05_AM__1__65fef965.jpeg"
                alt="MESARA AI Logo"
                className="w-12 h-12 rounded-xl object-contain bg-white p-1 border border-stone-200 shadow-sm"
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-heading font-black text-xl text-white">MESARA AI</span>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-400 text-stone-950">
                    Demo 01
                  </span>
                </div>
                <p className="text-xs text-indigo-200 font-medium">
                  Client Demonstration Suite · Retail & Kirana Storefront Concept
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto text-xs text-stone-700">
          
          <div className="space-y-2">
            <h3 className="font-heading font-extrabold text-base text-stone-900">
              Purpose of this Demonstration
            </h3>
            <p className="text-stone-600 leading-relaxed">
              This interactive prototype for <strong className="text-stone-900 font-bold">"Sri Lakshmi Stores"</strong> is engineered by <strong className="text-stone-900 font-bold">MESARA AI</strong> to demonstrate to retail shop owners how an intuitive, branded website accelerates their sales, protects their margins from food delivery aggregators, and modernizes their customer service.
            </p>
          </div>

          {/* Key Advantages for Shopkeepers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-2">
              <div className="w-8 h-8 rounded-lg bg-amber-200/80 text-amber-800 flex items-center justify-center font-bold text-sm">
                <MessageCircle className="w-4 h-4 text-amber-900" />
              </div>
              <h4 className="font-heading font-bold text-sm text-stone-900">
                1. Seamless WhatsApp Orders
              </h4>
              <p className="text-[11px] text-stone-600 leading-relaxed">
                Customers select pack sizes (e.g. 1kg, 5kg) and order immediately via WhatsApp without downloading third-party apps. Orders arrive neatly formatted on the shopkeeper's phone.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 space-y-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-200/80 text-emerald-800 flex items-center justify-center font-bold text-sm">
                <DollarSign className="w-4 h-4 text-emerald-900" />
              </div>
              <h4 className="font-heading font-bold text-sm text-stone-900">
                2. 0% Platform Commission
              </h4>
              <p className="text-[11px] text-stone-600 leading-relaxed">
                Aggregator delivery apps charge between 22% to 28% of grocery revenue. A dedicated MESARA AI website gives the shopkeeper 100% of their profits.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-indigo-50/70 border border-indigo-200/80 space-y-2">
              <div className="w-8 h-8 rounded-lg bg-indigo-200/80 text-indigo-800 flex items-center justify-center font-bold text-sm">
                <Smartphone className="w-4 h-4 text-indigo-900" />
              </div>
              <h4 className="font-heading font-bold text-sm text-stone-900">
                3. Instant UPI & Printed Invoices
              </h4>
              <p className="text-[11px] text-stone-600 leading-relaxed">
                Orders generate a professional cash memo / invoice with order numbers, customer address, and dynamic UPI QR codes for seamless doorstep payment.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-200/80 space-y-2">
              <div className="w-8 h-8 rounded-lg bg-purple-200/80 text-purple-800 flex items-center justify-center font-bold text-sm">
                <MapPin className="w-4 h-4 text-purple-900" />
              </div>
              <h4 className="font-heading font-bold text-sm text-stone-900">
                4. Local Pincode Delivery Checker
              </h4>
              <p className="text-[11px] text-stone-600 leading-relaxed">
                Customers enter their 6-digit postal code to instantly confirm 60-90 minute delivery eligibility and free delivery thresholds.
              </p>
            </div>

          </div>

          {/* Interactive Demo Presentation Steps */}
          <div className="p-4 rounded-2xl bg-stone-100 border border-stone-200 space-y-2.5">
            <h4 className="font-heading font-bold text-xs uppercase tracking-wider text-stone-800">
              Suggested 4-Step Client Walkthrough:
            </h4>
            <ol className="space-y-1.5 text-[11px] text-stone-600 list-decimal pl-4">
              <li>
                <strong className="text-stone-800">Step 1:</strong> Test the <em>Pincode Checker</em> in the hero (e.g., enter <code>560004</code>).
              </li>
              <li>
                <strong className="text-stone-800">Step 2:</strong> Click <em>"Quick Order on WhatsApp"</em> to preview how customer orders appear.
              </li>
              <li>
                <strong className="text-stone-800">Step 3:</strong> Add 2 items to the bag, click <em>"Proceed to Delivery"</em> and submit to see the printed receipt & QR.
              </li>
              <li>
                <strong className="text-stone-800">Step 4:</strong> Scroll down to the <em>"Commission Savings Calculator"</em> to calculate monthly return on investment.
              </li>
            </ol>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between gap-3">
          <div className="text-[11px] text-stone-500">
            Engineered by <strong className="text-stone-800 font-bold">MESARA AI</strong>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-stone-700 hover:bg-stone-200 cursor-pointer transition-colors"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onStartDemo();
              }}
              className="px-5 py-2 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors"
            >
              <span>Start Exploring Demo</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
