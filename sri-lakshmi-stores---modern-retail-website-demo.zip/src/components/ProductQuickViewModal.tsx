import React, { useState } from 'react';
import { Product } from '../types';
import { X, Star, ShoppingBag, MessageCircle, MapPin, CheckCircle2, ShieldCheck, Truck, Plus, Minus } from 'lucide-react';
import { STORE_INFO } from '../data/products';

interface ProductQuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, price: number, quantity: number) => void;
  onDirectWhatsApp: (product: Product, size: string, price: number) => void;
}

export const ProductQuickViewModal: React.FC<ProductQuickViewModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onDirectWhatsApp,
}) => {
  if (!product) return null;

  const [selectedSizeIndex, setSelectedSizeIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const currentVariant = product.availableSizes[selectedSizeIndex] || {
    size: product.unit,
    price: product.price,
    originalPrice: product.originalPrice,
  };

  const discount = Math.round(
    ((currentVariant.originalPrice - currentVariant.price) / currentVariant.originalPrice) * 100
  );

  const handleAdd = () => {
    onAddToCart(product, currentVariant.size, currentVariant.price, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-2xl w-full border border-stone-200 shadow-2xl overflow-hidden relative my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
          {/* Left Column: Visual Emblem & Quality Badges */}
          <div className="md:col-span-5 bg-gradient-to-br from-amber-50/80 via-stone-50 to-amber-100/40 p-6 flex flex-col items-center justify-between border-b md:border-b-0 md:border-r border-stone-200 text-center">
            <div className="w-full flex justify-between items-center text-[11px] text-stone-500">
              <span className="flex items-center gap-1 font-medium">
                <MapPin className="w-3 h-3 text-amber-700" />
                {product.origin}
              </span>
              {product.isBestSeller && (
                <span className="font-bold text-amber-800">★ Bestseller</span>
              )}
            </div>

            <div className="my-8">
              <div className="w-28 h-28 rounded-3xl bg-white shadow-sm border border-stone-200 flex items-center justify-center text-6xl mx-auto">
                {product.emoji}
              </div>
              <h4 className="mt-3 font-bold text-sm text-stone-800 font-heading">
                Sri Lakshmi Provisions
              </h4>
              <p className="text-[11px] text-stone-500">Hand-Inspected Batch</p>
            </div>

            <div className="w-full p-3 rounded-xl bg-white/80 border border-stone-200 text-left space-y-1 text-xs">
              <div className="flex items-center gap-1.5 text-stone-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Zero chemical polish</span>
              </div>
              <div className="flex items-center gap-1.5 text-stone-700">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>FSSAI Certified Fresh</span>
              </div>
              <div className="flex items-center gap-1.5 text-stone-700">
                <Truck className="w-3.5 h-3.5 text-amber-600" />
                <span>90-min express delivery</span>
              </div>
            </div>
          </div>

          {/* Right Column: Product Specs & Actions */}
          <div className="md:col-span-7 p-6 space-y-5">
            <div>
              <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
                <span>{product.categoryLabel}</span>
                {product.kannadaName && (
                  <span className="text-amber-800 font-medium">{product.kannadaName}</span>
                )}
              </div>
              <h3 className="font-heading font-extrabold text-xl text-stone-900 leading-snug">
                {product.name}
              </h3>
              
              <div className="flex items-center gap-3 mt-2 text-xs text-stone-500">
                <span className="flex items-center gap-1 font-bold text-stone-900">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                  {product.rating.toFixed(1)} / 5.0
                </span>
                <span>·</span>
                <span>{product.reviewCount} neighborhood families trust this</span>
              </div>
            </div>

            {/* Description */}
            <p className="text-xs text-stone-600 leading-relaxed">
              {product.description}
            </p>

            {/* Tags */}
            <div className="flex flex-wrap gap-1.5">
              {product.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-0.5 rounded text-[11px] font-medium bg-stone-100 text-stone-700 border border-stone-200"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Size Variant Selector */}
            <div className="space-y-2 pt-2 border-t border-stone-100">
              <label className="text-xs font-bold text-stone-800 block">Choose Quantity / Pack Size:</label>
              <div className="grid grid-cols-2 gap-2">
                {product.availableSizes.map((v, i) => (
                  <button
                    key={v.size}
                    onClick={() => setSelectedSizeIndex(i)}
                    className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                      selectedSizeIndex === i
                        ? 'bg-amber-50 border-amber-500 ring-1 ring-amber-400'
                        : 'bg-stone-50 border-stone-200 hover:bg-stone-100'
                    }`}
                  >
                    <span className="block text-xs font-bold text-stone-900">{v.size}</span>
                    <span className="text-xs text-stone-700 font-extrabold tabular-nums">₹{v.price}</span>
                    {v.originalPrice > v.price && (
                      <span className="text-[10px] text-stone-400 line-through ml-1.5 tabular-nums">
                        ₹{v.originalPrice}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Pricing Summary */}
            <div className="bg-stone-50 rounded-xl p-3 border border-stone-200 flex items-center justify-between">
              <div>
                <span className="text-xs text-stone-500 block">Total for {quantity} unit(s):</span>
                <div className="flex items-baseline gap-2">
                  <span className="text-xl font-black text-stone-900 tabular-nums">
                    ₹{currentVariant.price * quantity}
                  </span>
                  {discount > 0 && (
                    <span className="text-xs font-bold text-emerald-700">
                      Save {discount}%
                    </span>
                  )}
                </div>
              </div>

              {/* Quantity Stepper */}
              <div className="flex items-center border border-stone-300 rounded-lg bg-white px-1.5 py-1">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                  className="p-1 text-stone-500 hover:text-stone-900 disabled:opacity-30 cursor-pointer"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="w-8 text-center text-xs font-bold tabular-nums text-stone-800">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-1 text-stone-500 hover:text-stone-900 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-1">
              <button
                onClick={handleAdd}
                className={`w-full py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  added
                    ? 'bg-emerald-600 text-white'
                    : 'bg-stone-900 hover:bg-stone-800 text-white shadow-sm'
                }`}
              >
                <ShoppingBag className="w-4 h-4 text-amber-300" />
                <span>{added ? 'Added to Your Bag!' : 'Add to Shopping Bag'}</span>
              </button>

              <button
                onClick={() => {
                  onDirectWhatsApp(product, currentVariant.size, currentVariant.price * quantity);
                  onClose();
                }}
                className="w-full py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>Order Immediately on WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
