import React from 'react';
import { CATEGORIES } from '../data/products';
import { Filter, Star, Sparkles } from 'lucide-react';

interface CategoryFilterProps {
  selectedCategory: string;
  onSelectCategory: (id: string) => void;
  filterBestSellersOnly: boolean;
  onToggleBestSellers: () => void;
  sortBy: 'featured' | 'price-low' | 'price-high' | 'rating';
  onSortChange: (sort: 'featured' | 'price-low' | 'price-high' | 'rating') => void;
  totalProductsCount: number;
}

export const CategoryFilter: React.FC<CategoryFilterProps> = ({
  selectedCategory,
  onSelectCategory,
  filterBestSellersOnly,
  onToggleBestSellers,
  sortBy,
  onSortChange,
  totalProductsCount,
}) => {
  return (
    <div id="categories" className="space-y-4 pt-4">
      {/* Category Pills / Segmented Controls */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`px-4 py-2 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                isActive
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-white text-stone-700 hover:bg-stone-100 border border-stone-200/80'
              }`}
            >
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Filter and Sort Row */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs text-stone-600 border-t border-stone-200/70">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-medium text-stone-500">
            Showing <strong className="text-stone-900 tabular-nums">{totalProductsCount}</strong> authentic items
          </span>

          <span className="text-stone-300">·</span>

          {/* Best Seller filter toggle */}
          <button
            onClick={onToggleBestSellers}
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
              filterBestSellersOnly
                ? 'bg-amber-100 text-amber-900 border border-amber-300 font-semibold'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200/80 border border-transparent'
            }`}
          >
            <Star className={`w-3.5 h-3.5 ${filterBestSellersOnly ? 'fill-amber-500 text-amber-600' : 'text-stone-400'}`} />
            <span>Best Sellers Only</span>
          </button>
        </div>

        {/* Sort Dropdown */}
        <div className="flex items-center gap-2">
          <label htmlFor="sort-select" className="text-stone-500 font-medium">Sort by:</label>
          <select
            id="sort-select"
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value as any)}
            className="bg-white border border-stone-200 rounded-lg px-2.5 py-1 text-xs text-stone-800 font-medium focus:outline-none focus:border-amber-600 cursor-pointer"
          >
            <option value="featured">Featured / Tradition</option>
            <option value="rating">Highest Rated (★ 5.0)</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
          </select>
        </div>
      </div>
    </div>
  );
};
