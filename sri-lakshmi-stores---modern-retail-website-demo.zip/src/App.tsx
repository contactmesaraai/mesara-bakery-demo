/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { SAMPLE_PRODUCTS, STORE_INFO } from './data/products';
import { Product, CartItem, CustomerOrder } from './types';
import { DemoBanner } from './components/DemoBanner';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CategoryFilter } from './components/CategoryFilter';
import { ProductCard } from './components/ProductCard';
import { ProductQuickViewModal } from './components/ProductQuickViewModal';
import { WhatsAppOrderModal } from './components/WhatsAppOrderModal';
import { CartDrawer } from './components/CartDrawer';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { ShopOwnerValueSection } from './components/ShopOwnerValueSection';
import { StoreInfoSection } from './components/StoreInfoSection';
import { CustomerReviews } from './components/CustomerReviews';
import { Footer } from './components/Footer';
import { WalkthroughModal } from './components/WalkthroughModal';
import { ShoppingBag, ArrowUp, CheckCircle, Search, Sparkles } from 'lucide-react';

export default function App() {
  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([
    // Initial demo sample item so shopkeepers can see an active cart immediately
    {
      product: SAMPLE_PRODUCTS[0], // Sona Masoori
      selectedSize: '5 kg bag',
      price: 360,
      quantity: 1,
    },
    {
      product: SAMPLE_PRODUCTS[1], // A2 Desi Cow Ghee
      selectedSize: '500 ml',
      price: 649,
      quantity: 1,
    },
  ]);

  // UI state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);
  const [isWalkthroughOpen, setIsWalkthroughOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [completedOrder, setCompletedOrder] = useState<CustomerOrder | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Filter & Search state
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterBestSellersOnly, setFilterBestSellersOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'rating'>('featured');

  // Trigger brief toast notification
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2400);
  };

  // Cart operations
  const handleAddToCart = (product: Product, size: string, price: number, quantity: number) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex(
        (item) => item.product.id === product.id && item.selectedSize === size
      );

      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + quantity,
        };
        return next;
      } else {
        return [...prev, { product, selectedSize: size, price, quantity }];
      }
    });

    showToast(`Added ${quantity}x ${product.name} (${size}) to bag`);
  };

  const handleUpdateQty = (productId: string, size: string, delta: number) => {
    setCartItems((prev) => {
      return prev
        .map((item) => {
          if (item.product.id === productId && item.selectedSize === size) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveItem = (productId: string, size: string) => {
    setCartItems((prev) =>
      prev.filter((item) => !(item.product.id === productId && item.selectedSize === size))
    );
  };

  // Direct WhatsApp order for single item
  const handleDirectWhatsApp = (product: Product, size: string, price: number) => {
    const text = `*Namaskara Sri Lakshmi Stores!*\nI would like to order:\n- *${product.name}* (${size}) - ₹${price}\n\nPlease deliver to my address. Thank you!`;
    const url = `https://wa.me/${STORE_INFO.whatsappNumber}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCheckoutComplete = (order: CustomerOrder) => {
    setIsCartOpen(false);
    setCompletedOrder(order);
    // Clear cart on successful order
    setCartItems([]);
  };

  // Navigation scroll helper
  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Filtered & Sorted products
  const filteredProducts = useMemo(() => {
    return SAMPLE_PRODUCTS.filter((prod) => {
      // Category filter
      if (selectedCategory !== 'all' && prod.category !== selectedCategory) {
        return false;
      }
      // Best sellers filter
      if (filterBestSellersOnly && !prod.isBestSeller) {
        return false;
      }
      // Search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = prod.name.toLowerCase().includes(query);
        const matchesKannada = prod.kannadaName?.toLowerCase().includes(query) || false;
        const matchesDesc = prod.description.toLowerCase().includes(query);
        const matchesTags = prod.tags.some((t) => t.toLowerCase().includes(query));
        const matchesCategory = prod.categoryLabel.toLowerCase().includes(query);
        const matchesOrigin = prod.origin.toLowerCase().includes(query);
        if (!matchesName && !matchesKannada && !matchesDesc && !matchesTags && !matchesCategory && !matchesOrigin) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'price-low') return a.price - b.price;
      if (sortBy === 'price-high') return b.price - a.price;
      // featured: best sellers first, then original order
      if (a.isBestSeller && !b.isBestSeller) return -1;
      if (!a.isBestSeller && b.isBestSeller) return 1;
      return 0;
    });
  }, [selectedCategory, filterBestSellersOnly, searchQuery, sortBy]);

  // Cart summary calculations
  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const cartTotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900 selection:bg-amber-100 selection:text-amber-900">
      
      {/* 1. Top MESARA AI Demo Series Banner */}
      <DemoBanner onOpenWalkthrough={() => setIsWalkthroughOpen(true)} />

      {/* 2. Main Store Header with original MESARA AI Logo */}
      <Header
        cartCount={cartCount}
        cartTotal={cartTotal}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWhatsAppModal={() => setIsWhatsAppModalOpen(true)}
        onOpenWalkthrough={() => setIsWalkthroughOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onNavigateSection={handleNavigateSection}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        
        {/* 3. Hero Section with Pincode Checker */}
        <Hero
          onExploreCatalog={() => handleNavigateSection('catalog')}
          onOpenWhatsAppModal={() => setIsWhatsAppModalOpen(true)}
          onSelectCategory={(catId) => {
            setSelectedCategory(catId);
            handleNavigateSection('catalog');
          }}
        />

        {/* 4. Product Catalog Section */}
        <section id="catalog" className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
                  Daily Provisions Catalog
                </span>
                <span className="text-stone-300">·</span>
                <span className="text-xs text-stone-500 font-medium">FSSAI Certified</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-heading font-extrabold text-stone-900 tracking-tight mt-1">
                Hand-Picked Groceries & Spices
              </h2>
              <p className="text-xs sm:text-sm text-stone-600 mt-1 max-w-xl">
                Freshly stocked staples directly from local agricultural mills. Select required weights, review customer ratings, and place your order in seconds.
              </p>
            </div>

            {/* Quick stats badge */}
            <div className="hidden sm:flex items-center gap-3 text-xs text-stone-600 bg-white p-3 rounded-2xl border border-stone-200 shrink-0">
              <span className="flex items-center gap-1 font-semibold text-emerald-800">
                <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                In Stock & Ready
              </span>
              <span>·</span>
              <span>Same-Day 90-Min Dispatch</span>
            </div>
          </div>

          {/* Category & Filter Tabs */}
          <CategoryFilter
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            filterBestSellersOnly={filterBestSellersOnly}
            onToggleBestSellers={() => setFilterBestSellersOnly(!filterBestSellersOnly)}
            sortBy={sortBy}
            onSortChange={setSortBy}
            totalProductsCount={filteredProducts.length}
          />

          {/* Products Grid */}
          {filteredProducts.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-stone-200 space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-800 flex items-center justify-center text-2xl mx-auto">
                🔍
              </div>
              <h3 className="font-heading font-bold text-base text-stone-900">
                No matching provisions found
              </h3>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                We couldn't find items matching "{searchQuery}". Try searching for rice, toor dal, bilona ghee, or filter coffee.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory('all');
                  setFilterBestSellersOnly(false);
                }}
                className="px-4 py-2 rounded-xl bg-stone-900 text-white text-xs font-semibold hover:bg-stone-800 cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((prod) => (
                <ProductCard
                  key={prod.id}
                  product={prod}
                  onAddToCart={handleAddToCart}
                  onQuickView={(p) => setQuickViewProduct(p)}
                  onDirectWhatsApp={handleDirectWhatsApp}
                />
              ))}
            </div>
          )}
        </section>

        {/* 5. Special Shopkeeper Demonstration Section */}
        <ShopOwnerValueSection
          onOpenWhatsAppModal={() => setIsWhatsAppModalOpen(true)}
        />

        {/* 6. Physical Store Heritage & Gandhi Bazaar Map Info */}
        <StoreInfoSection />

        {/* 7. Neighborhood Customer Reviews */}
        <CustomerReviews />

      </main>

      {/* 8. Mandatory MESARA AI Footer */}
      <Footer
        onNavigateSection={handleNavigateSection}
        onOpenWhatsAppModal={() => setIsWhatsAppModalOpen(true)}
        onOpenWalkthrough={() => setIsWalkthroughOpen(true)}
      />

      {/* Floating Bottom Bag bar (Mobile & Tablet sticky CTA) */}
      {cartCount > 0 && !isCartOpen && (
        <div className="fixed bottom-4 inset-x-4 max-w-md mx-auto z-30 lg:hidden animate-in slide-in-from-bottom-4">
          <button
            onClick={() => setIsCartOpen(true)}
            className="w-full p-3.5 rounded-2xl bg-stone-950 text-white shadow-xl border border-stone-800 flex items-center justify-between cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="relative">
                <ShoppingBag className="w-5 h-5 text-amber-300" />
                <span className="absolute -top-1.5 -right-2 bg-amber-500 text-stone-950 text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              </div>
              <div className="text-left">
                <span className="block text-xs font-bold text-stone-100">
                  {cartCount} item{cartCount > 1 ? 's' : ''} in Bag
                </span>
                <span className="block text-[11px] text-stone-400">
                  {cartTotal >= STORE_INFO.freeDeliveryThreshold ? 'FREE Delivery unlocked' : `Add ₹${STORE_INFO.freeDeliveryThreshold - cartTotal} for FREE Delivery`}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm font-extrabold text-amber-300 tabular-nums">
                ₹{cartTotal}
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-amber-700 text-white text-xs font-bold">
                View Bag →
              </span>
            </div>
          </button>
        </div>
      )}

      {/* Floating Action / Walkthrough Trigger for Presentation */}
      <div className="fixed bottom-6 right-6 z-30 hidden lg:block">
        <button
          onClick={() => setIsWalkthroughOpen(true)}
          className="group flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-stone-900/90 hover:bg-stone-900 text-white text-xs font-bold shadow-lg border border-indigo-500/40 backdrop-blur-md transition-all hover:scale-105 cursor-pointer"
          title="MESARA AI Client Presentation Guide"
        >
          <img
            src="/assets/aistudio/WhatsApp_Image_2026-10-22_at_10.37.05_AM__1__65fef965.jpeg"
            alt="MESARA AI Logo"
            className="w-5 h-5 rounded object-contain bg-white p-0.5"
          />
          <span className="text-stone-200 group-hover:text-amber-300 transition-colors">
            MESARA AI Demo Guide
          </span>
        </button>
      </div>

      {/* Modals & Slide-out Drawers */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveItem}
        onCheckoutComplete={handleCheckoutComplete}
        onOpenWhatsAppModal={() => {
          setIsCartOpen(false);
          setIsWhatsAppModalOpen(true);
        }}
      />

      <ProductQuickViewModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onAddToCart={handleAddToCart}
        onDirectWhatsApp={handleDirectWhatsApp}
      />

      <WhatsAppOrderModal
        isOpen={isWhatsAppModalOpen}
        onClose={() => setIsWhatsAppModalOpen(false)}
        cartItems={cartItems}
        cartTotal={cartTotal}
      />

      <OrderSuccessModal
        order={completedOrder}
        onClose={() => setCompletedOrder(null)}
      />

      <WalkthroughModal
        isOpen={isWalkthroughOpen}
        onClose={() => setIsWalkthroughOpen(false)}
        onStartDemo={() => {
          handleNavigateSection('catalog');
        }}
      />

      {/* Floating brief feedback toast */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 p-3 rounded-xl bg-stone-900 text-white text-xs font-semibold shadow-xl border border-stone-700 flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
