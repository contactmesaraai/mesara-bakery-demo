export interface Product {
  id: string;
  name: string;
  kannadaName?: string;
  category: 'grains' | 'dals' | 'oils_ghee' | 'spices' | 'beverages' | 'snacks_dryfruits' | 'pooja';
  categoryLabel: string;
  price: number;
  originalPrice: number;
  unit: string;
  availableSizes: { size: string; price: number; originalPrice: number }[];
  description: string;
  origin: string;
  inStock: boolean;
  isBestSeller?: boolean;
  isNewHarvest?: boolean;
  rating: number;
  reviewCount: number;
  badge?: string;
  accentColor: string;
  emoji: string;
  tags: string[];
}

export interface CartItem {
  product: Product;
  selectedSize: string;
  price: number;
  quantity: number;
}

export interface CustomerOrder {
  orderId: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  pincode: string;
  deliverySlot: string;
  paymentMethod: 'cod' | 'upi' | 'pickup';
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  timestamp: string;
  orderNotes?: string;
}

export interface StoreReview {
  id: string;
  author: string;
  locality: string;
  rating: number;
  date: string;
  comment: string;
  verifiedCustomer: boolean;
}
