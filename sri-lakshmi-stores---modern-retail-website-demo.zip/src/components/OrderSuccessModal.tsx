import React, { useState } from 'react';
import { CustomerOrder } from '../types';
import { STORE_INFO } from '../data/products';
import { CheckCircle2, Printer, MessageCircle, X, QrCode, ArrowRight, ShieldCheck } from 'lucide-react';

interface OrderSuccessModalProps {
  order: CustomerOrder | null;
  onClose: () => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({ order, onClose }) => {
  if (!order) return null;

  const [printStatus, setPrintStatus] = useState(false);

  const handlePrint = () => {
    setPrintStatus(true);
    setTimeout(() => {
      window.print();
      setPrintStatus(false);
    }, 300);
  };

  const handleShareWhatsApp = () => {
    let text = `*Sri Lakshmi Stores - Digital Bill #${order.orderId}*\n`;
    text += `Customer: ${order.customerName} (${order.customerPhone})\n`;
    text += `Delivery Address: ${order.deliveryAddress}, ${order.pincode}\n`;
    text += `Slot: ${order.deliverySlot}\n\n`;
    text += `*Items Ordered:*\n`;
    order.items.forEach((item, i) => {
      text += `${i + 1}. ${item.product.name} (${item.selectedSize}) x ${item.quantity} = ₹${item.price * item.quantity}\n`;
    });
    text += `\nSubtotal: ₹${order.subtotal}`;
    text += `\nDelivery: ${order.deliveryFee === 0 ? 'FREE' : '₹' + order.deliveryFee}`;
    text += `\n*Total Payable: ₹${order.total}*`;
    text += `\nPayment Mode: ${order.paymentMethod.toUpperCase()}`;
    text += `\n\nThank you for shopping at Sri Lakshmi Stores, Gandhi Bazaar! 🙏`;

    const url = `https://wa.me/${order.customerPhone.replace(/\D/g, '') || STORE_INFO.whatsappNumber}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/70 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200 print:p-0 print:bg-white">
      <div className="bg-white rounded-3xl max-w-lg w-full border border-stone-200 shadow-2xl overflow-hidden relative my-6 print:border-none print:shadow-none print:rounded-none">
        
        {/* Success Header (Hidden in Print) */}
        <div className="bg-gradient-to-r from-emerald-800 to-emerald-900 text-white p-5 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-emerald-200" />
            </div>
            <div>
              <h3 className="font-heading font-bold text-lg text-white">Order Confirmed!</h3>
              <p className="text-xs text-emerald-200">Order ID: {order.orderId} · {order.timestamp}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Printable Indian Retail Cash Memo / Receipt */}
        <div className="p-6 space-y-4 text-xs text-stone-800 font-sans print:p-8">
          
          {/* Store Letterhead */}
          <div className="text-center pb-3 border-b border-stone-200 space-y-1">
            <h2 className="font-heading font-extrabold text-xl text-stone-900">
              SRI LAKSHMI STORES
            </h2>
            <p className="text-[11px] text-stone-600">
              Provisions, Pulses, Cold-Pressed Oils & Spices
            </p>
            <p className="text-[10px] text-stone-500">
              No. 42, Temple Road, Gandhi Bazaar Main, Basavanagudi, Bengaluru - 560004
            </p>
            <div className="flex justify-center items-center gap-3 text-[10px] text-stone-500 pt-1">
              <span>Ph: {STORE_INFO.phone}</span>
              <span>·</span>
              <span>FSSAI: {STORE_INFO.fssaiNumber}</span>
            </div>
          </div>

          {/* Invoice Metadata */}
          <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl bg-stone-50 border border-stone-200 text-[11px]">
            <div>
              <span className="text-stone-500 block">Order / Bill No:</span>
              <strong className="text-stone-900 font-bold">{order.orderId}</strong>
            </div>
            <div>
              <span className="text-stone-500 block">Delivery Slot:</span>
              <strong className="text-stone-900 font-bold">{order.deliverySlot}</strong>
            </div>
            <div>
              <span className="text-stone-500 block">Customer Name:</span>
              <strong className="text-stone-900 font-bold">{order.customerName}</strong>
            </div>
            <div>
              <span className="text-stone-500 block">Contact Phone:</span>
              <strong className="text-stone-900 font-bold">{order.customerPhone}</strong>
            </div>
            <div className="col-span-2">
              <span className="text-stone-500 block">Address:</span>
              <span className="text-stone-800">{order.deliveryAddress}, Bengaluru {order.pincode}</span>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-stone-300 text-stone-600 text-[11px]">
                  <th className="py-1.5 font-bold">Item Description</th>
                  <th className="py-1.5 text-center font-bold">Qty</th>
                  <th className="py-1.5 text-right font-bold">Rate</th>
                  <th className="py-1.5 text-right font-bold">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {order.items.map((item) => (
                  <tr key={`${item.product.id}-${item.selectedSize}`}>
                    <td className="py-2">
                      <span className="font-semibold text-stone-900 block">{item.product.name}</span>
                      <span className="text-[10px] text-stone-500">{item.selectedSize}</span>
                    </td>
                    <td className="py-2 text-center tabular-nums">{item.quantity}</td>
                    <td className="py-2 text-right tabular-nums">₹{item.price}</td>
                    <td className="py-2 text-right font-bold tabular-nums">
                      ₹{item.price * item.quantity}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals */}
          <div className="pt-2 border-t border-stone-200 space-y-1 text-xs">
            <div className="flex justify-between text-stone-600">
              <span>Subtotal:</span>
              <span className="tabular-nums font-semibold">₹{order.subtotal}</span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>Delivery Charges:</span>
              <span className="tabular-nums font-semibold">
                {order.deliveryFee === 0 ? <span className="text-emerald-700">FREE</span> : `₹${order.deliveryFee}`}
              </span>
            </div>
            <div className="flex justify-between text-sm font-extrabold text-stone-950 pt-1 border-t border-stone-300">
              <span>Total Payable Amount:</span>
              <span className="text-amber-800 tabular-nums">₹{order.total}</span>
            </div>
            <div className="flex justify-between text-[11px] text-stone-500 pt-0.5">
              <span>Payment Mode:</span>
              <span className="font-bold uppercase text-stone-800">
                {order.paymentMethod === 'upi' ? 'UPI on Delivery' : order.paymentMethod === 'cod' ? 'Cash on Delivery' : 'Counter Pickup'}
              </span>
            </div>
          </div>

          {/* UPI Scan to Pay Box (Simulated for shopkeeper) */}
          {order.paymentMethod === 'upi' && (
            <div className="p-3 rounded-xl bg-indigo-50/70 border border-indigo-200 text-center space-y-2">
              <span className="text-[11px] font-bold text-indigo-900 uppercase tracking-wider block">
                Instant UPI Payment on Delivery
              </span>
              <div className="w-24 h-24 bg-white rounded-xl mx-auto flex items-center justify-center border border-indigo-200 shadow-2xs">
                <QrCode className="w-18 h-18 text-stone-900" />
              </div>
              <p className="text-[10px] text-stone-600">
                UPI ID: <strong className="text-indigo-900">srilakshmistores@okaxis</strong>
              </p>
            </div>
          )}

          {/* Delivery Note */}
          <div className="text-center text-[10px] text-stone-500 pt-2 border-t border-stone-100">
            Estimated Arrival: Within 60-90 minutes via Gandhi Bazaar store delivery staff.
            <br />
            For any changes or additions, call <strong>{STORE_INFO.phone}</strong>.
          </div>
        </div>

        {/* Modal Bottom Actions (Hidden in Print) */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex flex-wrap items-center justify-between gap-3 print:hidden">
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Invoice</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShareWhatsApp}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors shadow-2xs"
            >
              <MessageCircle className="w-3.5 h-3.5 fill-white/20" />
              <span>Send Receipt via WhatsApp</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold cursor-pointer transition-colors"
            >
              Done
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
