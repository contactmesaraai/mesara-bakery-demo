import React from 'react';
import { STORE_INFO } from '../data/products';
import { MapPin, Phone, MessageCircle, Clock, ShieldCheck, Heart, Sparkles, ExternalLink } from 'lucide-react';

interface FooterProps {
  onNavigateSection: (id: string) => void;
  onOpenWhatsAppModal: () => void;
  onOpenWalkthrough: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigateSection,
  onOpenWhatsAppModal,
  onOpenWalkthrough,
}) => {
  return (
    <footer className="bg-stone-950 text-stone-300 pt-14 pb-10 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-12">
        
        {/* Main Store Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Col 1: Store Brand & Identity */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-600 to-amber-800 flex items-center justify-center text-white font-heading font-black text-xl shadow-xs">
                SL
              </div>
              <div>
                <h3 className="font-heading font-extrabold text-xl text-white tracking-tight">
                  Sri Lakshmi Stores
                </h3>
                <p className="text-xs text-amber-400 font-medium">
                  {STORE_INFO.kannadaName} · Est. 1984
                </p>
              </div>
            </div>

            <p className="text-xs text-stone-400 leading-relaxed">
              {STORE_INFO.description}
            </p>

            <div className="pt-2 text-xs space-y-1.5 text-stone-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>FSSAI License: <strong className="text-stone-200">{STORE_INFO.fssaiNumber}</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-400" />
                <span>Open 7 Days: 7:30 AM to 9:30 PM</span>
              </div>
            </div>
          </div>

          {/* Col 2: Store Navigation & Categories */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-200">
              Categories
            </h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li>
                <button
                  onClick={() => onNavigateSection('categories')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Rice, Atta & Grains
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('categories')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Unpolished Dals
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('categories')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Cold-Pressed Oils & Ghee
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('categories')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Salem Spices & Masalas
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('categories')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Degree Filter Coffee
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('categories')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Pooja Essentials
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Links & Delivery */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-200">
              Quick Links
            </h4>
            <ul className="space-y-2 text-xs text-stone-400">
              <li>
                <button
                  onClick={() => onNavigateSection('catalog')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Product Catalog
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('pincode-check')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Check Pincode Delivery
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenWhatsAppModal}
                  className="hover:text-emerald-400 transition-colors cursor-pointer text-emerald-400 flex items-center gap-1"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp Fast Order</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigateSection('story')}
                  className="hover:text-amber-400 transition-colors cursor-pointer"
                >
                  Gandhi Bazaar Store Story
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenWalkthrough}
                  className="hover:text-indigo-400 text-indigo-300 transition-colors cursor-pointer font-medium"
                >
                  Demo Guide for Shop Owners
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Store Contact & Location */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-stone-200">
              Store Contact & Hours
            </h4>
            <div className="space-y-2 text-xs text-stone-400">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span>{STORE_INFO.address}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Phone: <a href={`tel:${STORE_INFO.phone}`} className="text-stone-200 hover:underline">{STORE_INFO.phone}</a></span>
              </p>
              <p className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>WhatsApp: <strong className="text-stone-200">+91 98450 12345</strong></span>
              </p>
            </div>

            <div className="p-3 rounded-xl bg-stone-900 border border-stone-800 text-[11px] text-stone-400 space-y-1">
              <strong className="text-stone-200 block">Express Delivery Pincodes:</strong>
              <p>560004 (Gandhi Bazaar), 560019 (NR Colony), 560070 (Banashankari), 560085 (Kathriguppe), 560050 (Basavanagudi), 560001 (City Market)</p>
            </div>
          </div>

        </div>

        {/* MANDATORY MESARA AI BRANDING & DEVELOPER CREDIT SECTION */}
        <div className="pt-8 border-t border-stone-800/80">
          <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-stone-900 via-indigo-950/40 to-stone-900 border border-indigo-900/40 flex flex-col md:flex-row items-center justify-between gap-6">
            
            {/* Developer branding lockup with exact original logo */}
            <div className="flex items-center gap-4 text-center md:text-left">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-10-22_at_10.37.05_AM__1__65fef965.jpeg"
                alt="MESARA AI Original Logo"
                className="w-12 h-12 rounded-xl object-contain bg-white p-1 shadow-md border border-stone-300 shrink-0"
              />
              <div className="space-y-0.5">
                <div className="flex items-center gap-2 flex-wrap justify-center md:justify-start">
                  {/* Exact text "Built by MESARA AI" */}
                  <span className="font-heading font-extrabold text-white text-base tracking-tight">
                    Built by MESARA AI
                  </span>
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    Client Demo 01
                  </span>
                </div>
                <p className="text-xs text-indigo-200/90 font-medium">
                  Smart Solutions. Limitless Possibilities.
                </p>
                <p className="text-[11px] text-stone-400">
                  Tailored digital commerce solutions empowering local Indian retail stores to accept direct orders and scale their brand.
                </p>
              </div>
            </div>

            {/* Action for prospective shop owners viewing the demo */}
            <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
              <button
                onClick={onOpenWalkthrough}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>Explore Demo Features</span>
              </button>

              <a
                href="mailto:contact.mesara.ai@gmail.com"
                className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-semibold text-xs transition-colors border border-stone-700 flex items-center gap-1.5"
              >
                <span>Get a Website for Your Shop</span>
                <ExternalLink className="w-3 h-3 text-stone-400" />
              </a>
            </div>

          </div>

          {/* Legal / Copyright Bottom Line */}
          <div className="mt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-3">
            <p>
              © 2026 Sri Lakshmi Stores. All rights reserved. FSSAI Lic #11221334000892.
            </p>
            <p className="flex items-center gap-1 text-[11px]">
              <span>Demo prototype crafted with care</span>
              <span className="text-stone-400">·</span>
              <strong className="text-stone-300 font-medium">Built by MESARA AI</strong>
            </p>
          </div>

        </div>

      </div>
    </footer>
  );
};
