import React from 'react';
import { REVIEWS } from '../data/products';
import { Star, CheckCircle, Heart, Quote } from 'lucide-react';

export const CustomerReviews: React.FC = () => {
  return (
    <section className="py-14 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-2 max-w-xl">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
              Community Voices
            </span>
            <h2 className="text-2xl sm:text-3xl font-heading font-extrabold text-stone-900 tracking-tight">
              Loved by Basavanagudi & South Bangalore Homes
            </h2>
            <p className="text-xs sm:text-sm text-stone-600">
              Honest testimonials from neighbors who trust Sri Lakshmi Stores for their monthly and festival grocery provisions.
            </p>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-2xl bg-amber-50 border border-amber-200 shrink-0">
            <div className="flex items-center text-amber-500">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-500" />
              ))}
            </div>
            <div className="text-xs">
              <span className="font-extrabold text-stone-900 block tabular-nums">4.9 out of 5.0 Rating</span>
              <span className="text-[11px] text-stone-600">Based on 2,400+ local customer orders</span>
            </div>
          </div>
        </div>

        {/* Reviews Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {REVIEWS.map((rev) => (
            <div
              key={rev.id}
              className="p-5 rounded-2xl bg-stone-50/80 border border-stone-200/90 flex flex-col justify-between space-y-4 hover:border-amber-300 transition-colors"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-amber-500">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    ))}
                  </div>
                  <span className="text-[11px] text-stone-400">{rev.date}</span>
                </div>

                <p className="text-xs text-stone-700 leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>

              <div className="pt-3 border-t border-stone-200/70 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs text-stone-900 leading-tight">{rev.author}</h4>
                  <p className="text-[10px] text-stone-500">{rev.locality}</p>
                </div>
                {rev.verifiedCustomer && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    <CheckCircle className="w-3 h-3 text-emerald-600" />
                    Verified Buyer
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
