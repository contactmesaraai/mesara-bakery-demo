import React, { useState } from 'react';
import { TrendingUp, MessageCircle, DollarSign, Users, Smartphone, ShieldCheck, Check, X, ArrowRight } from 'lucide-react';

interface ShopOwnerValueSectionProps {
  onOpenWhatsAppModal: () => void;
}

export const ShopOwnerValueSection: React.FC<ShopOwnerValueSectionProps> = ({ onOpenWhatsAppModal }) => {
  const [dailyOrders, setDailyOrders] = useState(25);
  const [averageOrderValue, setAverageOrderValue] = useState(650);

  // Aggregator commission calculation (typically 22% to 28% for local grocery)
  const monthlyRevenue = dailyOrders * averageOrderValue * 30;
  const aggregatorCutPercent = 25;
  const monthlyLostToAggregator = Math.round(monthlyRevenue * (aggregatorCutPercent / 100));
  const yearlyLostToAggregator = monthlyLostToAggregator * 12;

  return (
    <section id="owner-benefits" className="py-14 bg-stone-900 text-stone-100 relative overflow-hidden border-y border-stone-800">
      {/* Decorative gradient glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>MESARA AI Client Demonstration Feature</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-heading font-extrabold tracking-tight text-white">
            Why Every Retail Storefront Needs Its Own Website
          </h2>
          <p className="text-sm sm:text-base text-stone-400">
            Showcasing how a bespoke website built by MESARA AI gives shop owners direct WhatsApp orders, 0% platform commission, and complete customer loyalty.
          </p>
        </div>

        {/* 3-Way Comparison Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Method 1: Traditional Phone & Diary */}
          <div className="bg-stone-800/60 rounded-2xl p-6 border border-stone-700/60 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-stone-400">Old Method</span>
              <span className="text-xl">📞</span>
            </div>
            <h3 className="font-heading font-bold text-lg text-white">Phone Calls & Khata Book</h3>
            <ul className="space-y-2.5 text-xs text-stone-300">
              <li className="flex items-start gap-2">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>Missed customer calls during shop peak hours</span>
              </li>
              <li className="flex items-start gap-2">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>Customers don’t know today’s prices or new items</span>
              </li>
              <li className="flex items-start gap-2">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>Repeated back-and-forth about item availability</span>
              </li>
            </ul>
          </div>

          {/* Method 2: Delivery Aggregator Apps */}
          <div className="bg-rose-950/20 rounded-2xl p-6 border border-rose-900/40 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-400">Aggregators (Apps)</span>
              <span className="text-xl">🛵</span>
            </div>
            <h3 className="font-heading font-bold text-lg text-rose-200">Blinkit / Zepto / Swiggy</h3>
            <ul className="space-y-2.5 text-xs text-stone-300">
              <li className="flex items-start gap-2">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span className="font-semibold text-rose-200">Huge 20% to 28% commission eaten</span>
              </li>
              <li className="flex items-start gap-2">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>You do not own customer phone numbers or data</span>
              </li>
              <li className="flex items-start gap-2">
                <X className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>Aggregator promotes competitor brands over yours</span>
              </li>
            </ul>
          </div>

          {/* Method 3: MESARA AI Storefront Website */}
          <div className="bg-gradient-to-b from-indigo-950/60 to-stone-800 rounded-2xl p-6 border-2 border-indigo-500/60 space-y-4 relative shadow-lg">
            <div className="absolute -top-3 right-4 px-2.5 py-0.5 rounded-full bg-gradient-to-r from-indigo-500 to-amber-500 text-white text-[10px] font-bold uppercase tracking-wider shadow-xs">
              Recommended
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-300">Your Own Store Website</span>
              <span className="text-xl">✨</span>
            </div>
            <h3 className="font-heading font-bold text-lg text-white">Built by MESARA AI</h3>
            <ul className="space-y-2.5 text-xs text-stone-200">
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span className="font-semibold text-emerald-300">0% Commission — 100% of profit is yours</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Neat WhatsApp orders with quantities, price & address</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>You own customer contacts for direct monthly repeat orders</span>
              </li>
              <li className="flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>Ranks on Google Maps when locals search for groceries</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Interactive Commission Savings Calculator */}
        <div className="bg-stone-800/90 rounded-3xl p-6 sm:p-8 border border-stone-700 max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-heading font-bold text-lg sm:text-xl text-white">
                Interactive Commission Savings Calculator
              </h3>
              <p className="text-xs text-stone-400">
                Move the sliders below to see how much your store saves with direct web orders vs delivery apps.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            {/* Sliders */}
            <div className="space-y-6">
              <div>
                <div className="flex items-center justify-between text-xs font-semibold mb-2">
                  <span className="text-stone-300">Daily Customer Delivery Orders:</span>
                  <span className="text-amber-400 font-bold text-sm tabular-nums">{dailyOrders} orders/day</span>
                </div>
                <input
                  type="range"
                  min={5}
                  max={100}
                  step={5}
                  value={dailyOrders}
                  onChange={(e) => setDailyOrders(Number(e.target.value))}
                  className="w-full accent-amber-500 h-2 bg-stone-700 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-stone-500 mt-1">
                  <span>5 orders</span>
                  <span>50 orders</span>
                  <span>100 orders</span>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between text-xs font-semibold mb-2">
                  <span className="text-stone-300">Average Order Value (AOV):</span>
                  <span className="text-amber-400 font-bold text-sm tabular-nums">₹{averageOrderValue}</span>
                </div>
                <input
                  type="range"
                  min={300}
                  max={2000}
                  step={50}
                  value={averageOrderValue}
                  onChange={(e) => setAverageOrderValue(Number(e.target.value))}
                  className="w-full accent-amber-500 h-2 bg-stone-700 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-stone-500 mt-1">
                  <span>₹300</span>
                  <span>₹1,000</span>
                  <span>₹2,000</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-stone-900/60 border border-stone-700/60 text-xs text-stone-300">
                <span className="text-stone-400 block mb-1">Monthly Gross Order Volume:</span>
                <span className="text-base font-bold text-white tabular-nums">
                  ₹{monthlyRevenue.toLocaleString('en-IN')}
                </span>
                <span className="text-stone-400 text-[11px] block mt-0.5">
                  ({dailyOrders * 30} monthly home delivery orders)
                </span>
              </div>
            </div>

            {/* Calculated Output Card */}
            <div className="bg-gradient-to-br from-stone-900 to-indigo-950 p-6 rounded-2xl border border-indigo-500/30 text-center space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-300">
                Aggregator Commission You Save Every Month
              </span>
              <div className="text-3xl sm:text-4xl font-extrabold font-heading text-emerald-400 tabular-nums">
                ₹{monthlyLostToAggregator.toLocaleString('en-IN')}
                <span className="text-xs text-stone-400 font-normal block mt-1">/ month saved in your pocket</span>
              </div>

              <div className="py-2 px-3 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-300">
                That's <strong className="font-bold text-white tabular-nums">₹{yearlyLostToAggregator.toLocaleString('en-IN')}</strong> in commissions saved every year!
              </div>

              <button
                onClick={onOpenWhatsAppModal}
                className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
                <span>Test Live WhatsApp Order Simulation</span>
              </button>
            </div>
          </div>
        </div>

        {/* Small Developer Attribution Callout */}
        <div className="mt-8 text-center text-xs text-stone-400 flex items-center justify-center gap-2">
          <span>Presented by</span>
          <span className="font-semibold text-white">MESARA AI</span>
          <span>· Custom digital storefronts engineered for retail shop owners.</span>
        </div>
      </div>
    </section>
  );
};
