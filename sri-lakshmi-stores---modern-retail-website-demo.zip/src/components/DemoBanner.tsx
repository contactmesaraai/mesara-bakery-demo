import React from 'react';
import { Sparkles, ArrowRight, ShieldCheck, TrendingUp } from 'lucide-react';

interface DemoBannerProps {
  onOpenWalkthrough: () => void;
}

export const DemoBanner: React.FC<DemoBannerProps> = ({ onOpenWalkthrough }) => {
  return (
    <aside aria-label="Demo notice" className="bg-gradient-to-r from-stone-900 via-indigo-950 to-stone-900 text-stone-100 text-xs py-2.5 px-4 border-b border-indigo-900/60 sticky top-0 z-50 shadow-xs">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 flex-wrap">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-500/20 text-indigo-200 border border-indigo-400/30">
            <Sparkles className="w-3 h-3 text-indigo-300" />
            MESARA AI · Client Demo 01
          </span>
          <span className="text-stone-300 hidden sm:inline">|</span>
          <p className="text-stone-200 font-medium">
            Modern Retail & Kirana Storefront Demo for <span className="text-amber-300 font-semibold">Sri Lakshmi Stores</span>
          </p>
          <span className="text-stone-400 hidden lg:inline text-[11px]">
            · Showing shop owners how a custom website drives direct WhatsApp orders with 0% commission
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenWalkthrough}
            className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-300 hover:text-amber-200 underline underline-offset-4 cursor-pointer transition-colors"
          >
            <TrendingUp className="w-3 h-3" />
            <span>Why Shop Owners Need This</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </aside>
  );
};
