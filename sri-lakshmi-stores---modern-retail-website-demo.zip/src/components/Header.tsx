import React, { useState } from 'react';
import { ShoppingBag, Search, Phone, MessageCircle, Menu, X, Clock, MapPin } from 'lucide-react';
import { STORE_INFO } from '../data/products';

interface HeaderProps {
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  onOpenWhatsAppModal: () => void;
  onOpenWalkthrough: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onNavigateSection: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  cartTotal,
  onOpenCart,
  onOpenWhatsAppModal,
  onOpenWalkthrough,
  searchQuery,
  onSearchChange,
  onNavigateSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const handleNavClick = (id: string) => {
    setMobileMenuOpen(false);
    onNavigateSection(id);
  };

  return (
    <header className="bg-white border-b border-stone-200/80 sticky top-[37px] z-40 transition-shadow duration-200 backdrop-blur-md bg-white/95">
      {/* Sub-header info bar */}
      <div className="bg-stone-50 border-b border-stone-100 text-[11px] text-stone-600 px-4 py-1 hidden md:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 font-medium text-stone-700">
              <MapPin className="w-3 h-3 text-amber-600" />
              Gandhi Bazaar Main, Bengaluru · Pincode 560004
            </span>
            <span>·</span>
            <span className="flex items-center gap-1 text-emerald-700 font-medium">
              <Clock className="w-3 h-3" />
              Open Today: 7:30 AM - 9:30 PM (Doorstep Delivery Active)
            </span>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-stone-500">Free delivery on orders above ₹{STORE_INFO.freeDeliveryThreshold}</span>
            <span>·</span>
            <a
              href={`tel:${STORE_INFO.phone}`}
              className="flex items-center gap-1 hover:text-stone-900 font-medium transition-colors"
            >
              <Phone className="w-3 h-3 text-stone-500" />
              Call Store: {STORE_INFO.phone}
            </a>
          </div>
        </div>
      </div>

      {/* Main Header Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
        {/* Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => handleNavClick('hero')}
            className="flex items-center gap-3 text-left group cursor-pointer"
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-amber-600 to-amber-800 flex items-center justify-center text-white shadow-sm ring-1 ring-amber-700/20 group-hover:scale-105 transition-transform">
              <span className="font-heading font-black text-xl tracking-tight">SL</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-heading font-bold text-lg sm:text-xl tracking-tight text-stone-900 group-hover:text-amber-800 transition-colors">
                  Sri Lakshmi Stores
                </span>
                <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 border border-amber-200">
                  Est. 1984
                </span>
              </div>
              <p className="text-[11px] text-stone-500 font-medium">
                Traditional Provisions & Fresh Spices
              </p>
            </div>
          </button>
        </div>

        {/* Center Navigation Links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-stone-700">
          <button
            onClick={() => handleNavClick('catalog')}
            className="hover:text-amber-700 transition-colors whitespace-nowrap cursor-pointer"
          >
            All Products
          </button>
          <button
            onClick={() => handleNavClick('categories')}
            className="hover:text-amber-700 transition-colors whitespace-nowrap cursor-pointer"
          >
            Categories
          </button>
          <button
            onClick={() => handleNavClick('pincode-check')}
            className="hover:text-amber-700 transition-colors whitespace-nowrap cursor-pointer"
          >
            Check Pincode
          </button>
          <button
            onClick={() => handleNavClick('story')}
            className="hover:text-amber-700 transition-colors whitespace-nowrap cursor-pointer"
          >
            Store Story & Location
          </button>
          <button
            onClick={() => handleNavClick('owner-benefits')}
            className="text-indigo-900 hover:text-indigo-700 font-semibold transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
            Shopkeeper Demo Insights
          </button>
        </nav>

        {/* Search bar on desktop */}
        <div className="hidden md:flex items-center relative flex-1 max-w-xs mx-2">
          <Search className="w-4 h-4 absolute left-3 text-stone-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setIsSearchFocused(false)}
            placeholder="Search rice, ghee, toor dal, coffee..."
            className={`w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border bg-stone-50/80 text-stone-900 placeholder:text-stone-400 focus:outline-none focus:bg-white transition-all ${
              isSearchFocused ? 'border-amber-500 ring-2 ring-amber-100 bg-white' : 'border-stone-200 hover:border-stone-300'
            }`}
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-2.5 text-xs text-stone-400 hover:text-stone-700"
            >
              ✕
            </button>
          )}
        </div>

        {/* Right Action Zone */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Quick WhatsApp Order Button */}
          <button
            onClick={onOpenWhatsAppModal}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 transition-colors cursor-pointer"
            title="Order directly over WhatsApp without installing an app"
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-600 fill-emerald-600/20" />
            <span className="whitespace-nowrap">Order on WhatsApp</span>
          </button>

          {/* Cart Trigger */}
          <button
            onClick={onOpenCart}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-stone-900 text-white hover:bg-stone-800 transition-colors shadow-xs cursor-pointer relative"
            aria-label="Shopping Cart"
          >
            <div className="relative">
              <ShoppingBag className="w-4 h-4 text-amber-300" />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-amber-500 text-stone-950 text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </div>
            <div className="text-left hidden sm:block">
              <span className="block text-[10px] text-stone-300 uppercase tracking-wider leading-none">Bag</span>
              <span className="block text-xs font-bold text-amber-300 leading-tight tabular-nums">
                ₹{cartTotal}
              </span>
            </div>
          </button>

          {/* MESARA AI Logo & Badge neatly integrated in Header */}
          <div
            onClick={onOpenWalkthrough}
            className="flex items-center gap-2 pl-2 sm:pl-3 border-l border-stone-200 cursor-pointer group"
            title="Built by MESARA AI - View shop owner demo details"
          >
            <img
              src="/assets/aistudio/WhatsApp_Image_2026-10-22_at_10.37.05_AM__1__65fef965.jpeg"
              alt="MESARA AI Logo"
              className="w-8 h-8 rounded-md object-contain border border-stone-200 bg-white p-0.5 shadow-2xs group-hover:scale-105 transition-transform"
            />
            <div className="hidden xl:block text-left">
              <span className="block text-[9px] uppercase tracking-wider font-bold text-indigo-600 leading-tight">
                Demo By
              </span>
              <span className="block text-[11px] font-bold text-stone-800 group-hover:text-indigo-600 transition-colors leading-tight">
                MESARA AI
              </span>
            </div>
          </div>

          {/* Mobile menu toggle button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-lg text-stone-600 hover:text-stone-900 hover:bg-stone-100 cursor-pointer"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Search Bar */}
      <div className="md:hidden px-4 pb-2.5">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search rice, ghee, spices, dal..."
            className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-stone-200 bg-stone-50 text-stone-900 placeholder:text-stone-400 focus:outline-none focus:bg-white focus:border-amber-500"
          />
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-stone-200 px-4 py-4 space-y-3">
          <div className="flex flex-col gap-2 text-sm font-medium text-stone-700">
            <button
              onClick={() => handleNavClick('catalog')}
              className="text-left py-2 px-2 rounded-md hover:bg-stone-100"
            >
              All Products & Provisions
            </button>
            <button
              onClick={() => handleNavClick('categories')}
              className="text-left py-2 px-2 rounded-md hover:bg-stone-100"
            >
              Shop by Category
            </button>
            <button
              onClick={() => handleNavClick('pincode-check')}
              className="text-left py-2 px-2 rounded-md hover:bg-stone-100"
            >
              Check Same-Day Delivery Pincode
            </button>
            <button
              onClick={() => handleNavClick('story')}
              className="text-left py-2 px-2 rounded-md hover:bg-stone-100"
            >
              Store Story & Gandhi Bazaar Map
            </button>
            <button
              onClick={() => handleNavClick('owner-benefits')}
              className="text-left py-2 px-2 rounded-md bg-indigo-50 text-indigo-900 font-semibold"
            >
              Shopkeeper Demo: See Business Benefits
            </button>
          </div>

          <div className="pt-2 border-t border-stone-200 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenWhatsAppModal();
              }}
              className="w-full py-2.5 rounded-lg bg-emerald-600 text-white font-medium text-xs flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              Order Fast via WhatsApp (+91 98450 12345)
            </button>

            {/* MESARA AI note in mobile drawer */}
            <div className="p-3 rounded-lg bg-stone-100 border border-stone-200 flex items-center gap-3">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-10-22_at_10.37.05_AM__1__65fef965.jpeg"
                alt="MESARA AI"
                className="w-8 h-8 rounded object-contain bg-white p-0.5 border border-stone-200"
              />
              <div className="text-left text-xs">
                <span className="font-bold text-stone-800">Designed & Engineered by MESARA AI</span>
                <p className="text-[11px] text-stone-500">Retail Client Demo Series · Demo 01</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
