import React, { useState } from 'react';
import { CartItem, CustomerOrder } from '../types';
import { STORE_INFO } from '../data/products';
import { X, ShoppingBag, Trash2, Plus, Minus, ArrowRight, MessageCircle, ShieldCheck, Truck, Check } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQty: (productId: string, size: string, delta: number) => void;
  onRemoveItem: (productId: string, size: string) => void;
  onCheckoutComplete: (order: CustomerOrder) => void;
  onOpenWhatsAppModal: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQty,
  onRemoveItem,
  onCheckoutComplete,
  onOpenWhatsAppModal,
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<'cart' | 'details'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('42, 3rd Main, Temple Road, Basavanagudi');
  const [pincode, setPincode] = useState('560004');
  const [deliverySlot, setDeliverySlot] = useState('Express (60-90 mins)');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'upi' | 'pickup'>('upi');
  const [orderNotes, setOrderNotes] = useState('');
  const [formError, setFormError] = useState('');

  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const isFreeDelivery = subtotal >= STORE_INFO.freeDeliveryThreshold;
  const deliveryFee = paymentMethod === 'pickup' ? 0 : (isFreeDelivery ? 0 : STORE_INFO.deliveryFee);
  const total = subtotal + deliveryFee;
  const amountNeededForFree = Math.max(0, STORE_INFO.freeDeliveryThreshold - subtotal);

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim() || !deliveryAddress.trim()) {
      setFormError('Please enter your Name, Phone Number, and Delivery Address.');
      return;
    }
    setFormError('');

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const newOrder: CustomerOrder = {
      orderId: `SLS-${randomSuffix}`,
      customerName,
      customerPhone,
      deliveryAddress,
      pincode,
      deliverySlot,
      paymentMethod,
      items: [...cartItems],
      subtotal,
      deliveryFee,
      total,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      orderNotes,
    };

    onCheckoutComplete(newOrder);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-stone-950/50 backdrop-blur-xs transition-opacity duration-200"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between">
          
          {/* Top Bar */}
          <div className="p-4 sm:p-5 border-b border-stone-200 bg-stone-50 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-stone-900 text-amber-300 flex items-center justify-center">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-heading font-bold text-base text-stone-900 leading-tight">
                  {step === 'cart' ? 'Your Shopping Bag' : 'Delivery & Payment'}
                </h3>
                <p className="text-[11px] text-stone-500">
                  {cartItems.length} unique item{cartItems.length !== 1 ? 's' : ''} from Sri Lakshmi Stores
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-stone-500 hover:text-stone-900 hover:bg-stone-200 cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Free Delivery Bar */}
          <div className="bg-amber-50 px-4 py-2 border-b border-amber-200/80 text-xs">
            {isFreeDelivery ? (
              <span className="text-emerald-800 font-bold flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-600" />
                Congratulations! You’ve unlocked FREE Doorstep Delivery!
              </span>
            ) : (
              <div className="space-y-1">
                <div className="flex justify-between text-stone-700">
                  <span>Add <strong className="text-amber-800 tabular-nums">₹{amountNeededForFree}</strong> more for <strong>FREE Delivery</strong></span>
                  <span className="text-[11px] text-stone-500 tabular-nums">₹{subtotal}/₹{STORE_INFO.freeDeliveryThreshold}</span>
                </div>
                <div className="w-full h-1.5 bg-amber-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-amber-600 transition-all duration-300"
                    style={{ width: `${Math.min(100, (subtotal / STORE_INFO.freeDeliveryThreshold) * 100)}%` }}
                  ></div>
                </div>
              </div>
            )}
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {cartItems.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <div className="w-16 h-16 rounded-2xl bg-stone-100 flex items-center justify-center text-3xl mx-auto">
                  🛒
                </div>
                <h4 className="font-heading font-bold text-stone-800 text-base">Your shopping bag is empty</h4>
                <p className="text-xs text-stone-500 max-w-xs mx-auto">
                  Add fresh pulses, cold-pressed oils, or fragrant filter coffee to start your order.
                </p>
                <button
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-amber-700 text-white text-xs font-semibold hover:bg-amber-800 cursor-pointer transition-colors"
                >
                  Browse Store Catalog
                </button>
              </div>
            ) : step === 'cart' ? (
              /* Step 1: Itemized Cart */
              <div className="space-y-3">
                {cartItems.map((item) => (
                  <div
                    key={`${item.product.id}-${item.selectedSize}`}
                    className="p-3 rounded-xl border border-stone-200 bg-white shadow-2xs flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-lg bg-stone-100 flex items-center justify-center text-xl shrink-0">
                        {item.product.emoji}
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-bold text-xs text-stone-900 truncate">{item.product.name}</h4>
                        <div className="flex items-center gap-2 text-[11px] text-stone-500">
                          <span>{item.selectedSize}</span>
                          <span>·</span>
                          <span className="font-semibold text-stone-800 tabular-nums">₹{item.price} each</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {/* Quantity Stepper */}
                      <div className="flex items-center border border-stone-200 rounded-lg bg-stone-50 px-1 py-0.5">
                        <button
                          onClick={() => onUpdateQty(item.product.id, item.selectedSize, -1)}
                          className="p-1 text-stone-600 hover:text-stone-900 cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-6 text-center text-xs font-bold tabular-nums text-stone-800">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQty(item.product.id, item.selectedSize, 1)}
                          className="p-1 text-stone-600 hover:text-stone-900 cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Total for item */}
                      <span className="text-xs font-extrabold text-stone-900 w-12 text-right tabular-nums">
                        ₹{item.price * item.quantity}
                      </span>

                      {/* Remove */}
                      <button
                        onClick={() => onRemoveItem(item.product.id, item.selectedSize)}
                        className="p-1 text-stone-400 hover:text-rose-600 cursor-pointer transition-colors"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}

                {/* Subtotal preview card */}
                <div className="pt-2">
                  <button
                    onClick={() => setStep('details')}
                    className="w-full py-3 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <span>Proceed to Delivery & Payment</span>
                    <ArrowRight className="w-3.5 h-3.5 text-amber-300" />
                  </button>

                  <div className="relative my-3 text-center">
                    <span className="bg-white px-2 text-[10px] uppercase font-bold text-stone-400 relative z-10">or</span>
                    <div className="absolute inset-x-0 top-2 border-t border-stone-200"></div>
                  </div>

                  <button
                    onClick={onOpenWhatsAppModal}
                    className="w-full py-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <MessageCircle className="w-4 h-4 text-emerald-600" />
                    <span>Send Order Immediately on WhatsApp</span>
                  </button>
                </div>
              </div>
            ) : (
              /* Step 2: Checkout Form */
              <form onSubmit={handleSubmitOrder} className="space-y-4 text-xs">
                {formError && (
                  <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs">
                    {formError}
                  </div>
                )}

                <div className="space-y-3">
                  <div>
                    <label className="font-bold text-stone-700 block mb-1">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="e.g. S. Radhakrishnan"
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-stone-50 focus:bg-white focus:outline-none focus:border-amber-600 text-stone-900 text-xs"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-stone-700 block mb-1">Mobile Number (For Delivery Call & SMS) *</label>
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="e.g. 9845012345"
                      className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-stone-50 focus:bg-white focus:outline-none focus:border-amber-600 text-stone-900 text-xs"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-2">
                      <label className="font-bold text-stone-700 block mb-1">Delivery Address *</label>
                      <input
                        type="text"
                        required
                        value={deliveryAddress}
                        onChange={(e) => setDeliveryAddress(e.target.value)}
                        placeholder="House/Apt No., Street, Landmark"
                        className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-stone-50 focus:bg-white focus:outline-none focus:border-amber-600 text-stone-900 text-xs"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-stone-700 block mb-1">Pincode *</label>
                      <input
                        type="text"
                        required
                        maxLength={6}
                        value={pincode}
                        onChange={(e) => setPincode(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-stone-300 bg-stone-50 focus:bg-white focus:outline-none focus:border-amber-600 text-stone-900 text-xs"
                      />
                    </div>
                  </div>

                  {/* Delivery Slot */}
                  <div>
                    <label className="font-bold text-stone-700 block mb-1">Select Delivery Slot:</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setDeliverySlot('Express (60-90 mins)')}
                        className={`p-2 rounded-lg border text-left transition-colors cursor-pointer ${
                          deliverySlot.includes('Express')
                            ? 'bg-amber-50 border-amber-600 font-bold text-amber-900'
                            : 'bg-stone-50 border-stone-200 text-stone-700'
                        }`}
                      >
                        ⚡ Express (60-90m)
                      </button>
                      <button
                        type="button"
                        onClick={() => setDeliverySlot('Evening (5 PM - 8 PM)')}
                        className={`p-2 rounded-lg border text-left transition-colors cursor-pointer ${
                          deliverySlot.includes('Evening')
                            ? 'bg-amber-50 border-amber-600 font-bold text-amber-900'
                            : 'bg-stone-50 border-stone-200 text-stone-700'
                        }`}
                      >
                        🌆 Evening (5-8 PM)
                      </button>
                    </div>
                  </div>

                  {/* Payment Method */}
                  <div>
                    <label className="font-bold text-stone-700 block mb-1">Payment Method:</label>
                    <div className="space-y-1.5">
                      <label className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                        paymentMethod === 'upi' ? 'bg-indigo-50 border-indigo-400 font-semibold' : 'bg-stone-50 border-stone-200'
                      }`}>
                        <input
                          type="radio"
                          name="payment"
                          checked={paymentMethod === 'upi'}
                          onChange={() => setPaymentMethod('upi')}
                          className="accent-indigo-600"
                        />
                        <div className="text-xs">
                          <span className="block text-stone-900 font-bold">UPI on Delivery (GPay / PhonePe / QR)</span>
                          <span className="text-[11px] text-stone-500">Scan QR on delivery boy's phone when items arrive</span>
                        </div>
                      </label>

                      <label className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                        paymentMethod === 'cod' ? 'bg-amber-50 border-amber-400 font-semibold' : 'bg-stone-50 border-stone-200'
                      }`}>
                        <input
                          type="radio"
                          name="payment"
                          checked={paymentMethod === 'cod'}
                          onChange={() => setPaymentMethod('cod')}
                          className="accent-amber-600"
                        />
                        <div className="text-xs">
                          <span className="block text-stone-900 font-bold">Cash on Delivery (COD)</span>
                          <span className="text-[11px] text-stone-500">Pay cash upon inspection at doorstep</span>
                        </div>
                      </label>

                      <label className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${
                        paymentMethod === 'pickup' ? 'bg-stone-100 border-stone-400 font-semibold' : 'bg-stone-50 border-stone-200'
                      }`}>
                        <input
                          type="radio"
                          name="payment"
                          checked={paymentMethod === 'pickup'}
                          onChange={() => setPaymentMethod('pickup')}
                          className="accent-stone-900"
                        />
                        <div className="text-xs">
                          <span className="block text-stone-900 font-bold">Store Pickup (Gandhi Bazaar Counter)</span>
                          <span className="text-[11px] text-stone-500">Packed & kept ready at our counter in 30 mins</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  <div>
                    <label className="font-bold text-stone-700 block mb-1">Optional Notes for Shopkeeper:</label>
                    <input
                      type="text"
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      placeholder="e.g. Leave with security, call on arrival"
                      className="w-full px-3 py-1.5 rounded-lg border border-stone-300 bg-stone-50 text-stone-900 text-xs"
                    />
                  </div>
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setStep('cart')}
                    className="px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 font-semibold text-xs cursor-pointer"
                  >
                    Back to Items
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
                  >
                    <span>Confirm Order (₹{total})</span>
                    <Check className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Footer Bill Breakdown */}
          {cartItems.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-stone-200 bg-stone-50 space-y-2 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Items Subtotal:</span>
                <span className="font-semibold text-stone-900 tabular-nums">₹{subtotal}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Doorstep Delivery:</span>
                <span className="font-semibold tabular-nums">
                  {deliveryFee === 0 ? (
                    <span className="text-emerald-700 font-bold">FREE</span>
                  ) : (
                    `₹${deliveryFee}`
                  )}
                </span>
              </div>
              <div className="flex justify-between text-sm font-extrabold text-stone-950 pt-1 border-t border-stone-200">
                <span>Total Amount:</span>
                <span className="text-amber-800 tabular-nums">₹{total}</span>
              </div>
              <p className="text-[10px] text-stone-500 text-center pt-1">
                Prices include all local taxes. FSSAI certified provisions.
              </p>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
